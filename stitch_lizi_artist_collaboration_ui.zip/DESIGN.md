---
name: Nocturnal Fluidity
colors:
  surface: '#15121b'
  surface-dim: '#15121b'
  surface-bright: '#3b3742'
  surface-container-lowest: '#0f0d15'
  surface-container-low: '#1d1a23'
  surface-container: '#211e27'
  surface-container-high: '#2c2832'
  surface-container-highest: '#37333d'
  on-surface: '#e7e0ed'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e7e0ed'
  inverse-on-surface: '#322f39'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#e6feff'
  on-secondary: '#003739'
  secondary-container: '#00f4fe'
  on-secondary-container: '#006c71'
  tertiary: '#ffb869'
  on-tertiary: '#482900'
  tertiary-container: '#ca801e'
  on-tertiary-container: '#3f2300'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#63f7ff'
  secondary-fixed-dim: '#00dce5'
  on-secondary-fixed: '#002021'
  on-secondary-fixed-variant: '#004f53'
  tertiary-fixed: '#ffdcbb'
  tertiary-fixed-dim: '#ffb869'
  on-tertiary-fixed: '#2c1700'
  on-tertiary-fixed-variant: '#673d00'
  background: '#15121b'
  on-background: '#e7e0ed'
  surface-variant: '#37333d'
typography:
  display-lg:
    fontFamily: Epilogue
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-md:
    fontFamily: Epilogue
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  title-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.08em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 24px
  gutter: 16px
  section-gap: 48px
  stack-tight: 4px
  stack-loose: 32px
---

## Brand & Style

The design system is engineered for a high-energy social collaboration environment, drawing its DNA from the immersive, late-night aesthetic of premium music streaming platforms. It prioritizes depth, focus, and a sense of "premium flow." The brand personality is sophisticated yet energetic, utilizing high-contrast accents to pierce through a moody, atmospheric backdrop.

The core design style is **Glassmorphism**, leveraging frosted textures and multi-layered translucency to create a sense of physical space. By using deep blacks (#000000) as the foundation and dark grays (#121212) for surface elevation, the UI achieves a "boundless" feel where content appears to float in a void, anchored only by soft light refractions and vibrant interactive nodes.

## Colors

The color palette centers on absolute darkness to minimize eye strain and maximize the pop of the primary accent. 

- **Primary Accent:** A vibrant, electric purple (#8B5CF6) used for high-intent actions and active states.
- **Secondary Accent:** A cyan neon (#00F5FF) used sparingly for collaborative indicators or secondary success states.
- **Neutrals:** The background is a true black (#000000), while interactive surfaces use a slightly lighter dark gray (#121212). 
- **Overlays:** Glass effects utilize white with extremely low opacity (8-12%) for strokes and fills, ensuring legibility against the dark void without losing the sense of transparency.

## Typography

This design system uses a dual-font strategy to balance editorial impact with social warmth. 

- **Headlines:** Epilogue provides a geometric, bold, and slightly futuristic feel. High-level headers should use tight tracking and heavy weights to create a "poster-like" visual hierarchy.
- **Body & Labels:** Be Vietnam Pro offers a friendly, contemporary tone that remains highly legible in dark mode. Its open counters prevent "letter-clogging" on high-density social feeds.
- **Formatting:** Use All-Caps for labels and metadata to distinguish them clearly from conversational body text.

## Layout & Spacing

The layout philosophy follows a **Fluid Grid** with generous inner margins to evoke the "Ample Whitespace" requirement. 

- **The 8px Rhythm:** All spacing must be a multiple of 8.
- **Content Density:** Elements should be spaced widely (32px+) to prevent the dark UI from feeling claustrophobic.
- **Edge-to-Edge Logic:** Mobile views and card-based feeds should span the full width of the viewport, using internal padding rather than external margins to maintain a modern, immersive streaming-app aesthetic.
- **Vertical Rhythm:** Use larger gaps (48px) between major functional sections (e.g., "Active Collaborations" vs "Discovery Feed").

## Elevation & Depth

Depth is not communicated through traditional drop shadows, but through **Tonal Layering** and **Backdrop Blurs**.

1.  **Level 0 (Base):** Pure #000000.
2.  **Level 1 (Surfaces):** #121212 with a subtle 1px border of `glass_stroke`.
3.  **Level 2 (Glass Overlays):** Semi-transparent surfaces with a `backdrop-filter: blur(20px)`. These are used for navigation bars and floating action menus.
4.  **Interactive Glow:** When an element is focused or active, apply a subtle outer glow using the Primary Accent color with 20% opacity and a 40px blur radius to simulate a light source behind the glass.

## Shapes

The shape language is defined by extreme roundedness, specifically a **32px corner radius** for primary containers.

- **Primary Containers:** 32px (rounded-xl) to create a soft, organic feel.
- **Interactive Elements:** Pill-shaped (fully rounded) for buttons and navigation items.
- **Media:** Profile avatars and thumbnails should follow a "squircle" or fully circular path to contrast against the sharp-edged text content.
- **Strokes:** Use ultra-thin (1px or 1.5px) borders for glass containers to maintain a delicate, high-fidelity appearance.

## Components

- **Pill-Shaped Navigation:** Bottom or top bars should be floating glass pills with 32px+ padding. Icons should be monochrome, turning to the Primary Accent when active.
- **Edge-to-Edge Cards:** Social posts and collaborative workspaces are housed in cards that touch the screen edges horizontally. Use a 32px radius for the internal corners and separate cards with 16px vertical gutters.
- **Filter Chips:** Fully rounded (pill) shapes. Use a subtle #121212 fill for inactive chips and a solid Primary Accent fill for active states.
- **Buttons:** Large, high-profile buttons should be pill-shaped with bold Epilogue text. Primary buttons use the Primary Accent; Ghost buttons use a `glass_stroke` border.
- **Input Fields:** Recessed into the #121212 surface with a 16px radius. Focus states should trigger a thin Primary Accent border.
- **Collaboration Indicators:** Small, vibrant "pips" or glow-rings around avatars to indicate who is currently online or typing within a shared workspace.